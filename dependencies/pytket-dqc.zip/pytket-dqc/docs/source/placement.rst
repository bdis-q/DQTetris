Placement
=========

.. autoclass:: pytket_dqc.placement.placement.Placement

    .. automethod:: Placement.__init__

    .. automethod:: Placement.is_valid

    .. automethod:: Placement.get_distribution_tree

    .. automethod:: Placement.to_dict

    .. automethod:: Placement.from_dict