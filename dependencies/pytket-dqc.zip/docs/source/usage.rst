Usage
=====

.. _installation:

Installation
------------

To use pytket-dqc requires the instillation of
`kahypar <https://github.com/kahypar/kahypar>`_ and
`graphviz <https://graphviz.org/download/>`_. pytket-dqc can then be
installed using pip:

.. code-block: : console

> pip install .
